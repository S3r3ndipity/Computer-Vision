

% subplot(2, 2, 4); imshow(synthim4); title('window size = 13');
% print -dpng 'output3c.png'
